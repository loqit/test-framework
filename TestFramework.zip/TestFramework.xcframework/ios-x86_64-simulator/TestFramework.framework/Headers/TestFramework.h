//
//  TestFramework.h
//  TestFramework
//
//  Created by Bobr, Andrey on 8.11.22.
//

#import <Foundation/Foundation.h>

//! Project version number for TestFramework.
FOUNDATION_EXPORT double TestFrameworkVersionNumber;

//! Project version string for TestFramework.
FOUNDATION_EXPORT const unsigned char TestFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TestFramework/PublicHeader.h>


